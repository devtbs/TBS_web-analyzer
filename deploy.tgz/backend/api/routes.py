from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks, Request, Body
from fastapi.responses import StreamingResponse
from typing import List
from sqlalchemy.orm import Session
from models.schemas import (
    URLAnalysisRequest, AnalysisResponse, TokenResponse,
    UserInfo, KnowledgeGraphData, TopicalMapData, ComparisonData,
    FullAnalysisResult, BriefRequest, DocumentResponse, DocumentDetailResponse
)
from auth.auth import verify_google_token, create_access_token, get_current_user
from datetime import datetime, timezone
import pytz
from services import scraper, kg_generator, topical_generator, comparator
from services.brief_generator import generate_content_brief
from utils.storage import database_store
from utils.progress_tracker import progress_tracker
from database import get_db, Document
from config import settings
from datetime import datetime
import uuid
from datetime import datetime
import asyncio
import json

router = APIRouter()


# ============= Authentication Routes =============

@router.post("/auth/google/login", response_model=TokenResponse)
async def google_login(request: dict, db: Session = Depends(get_db)):
    """Login with Google OAuth token"""
    from utils.user_manager import get_or_create_user
    
    token = request.get('token')
    if not token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Token is required"
        )
    
    # Verify Google token
    user_info = await verify_google_token(token)
    
    # Create or update user in database
    db_user = get_or_create_user(
        db,
        email=user_info.email,
        name=user_info.name,
        picture=user_info.picture
    )
    
    # Create JWT access token
    access_token = create_access_token(
        data={
            "sub": user_info.email,
            "name": user_info.name,
            "picture": user_info.picture,
            "gsc_connected": db_user.gsc_token is not None
        }
    )
    
    return TokenResponse(
        access_token=access_token,
        user=user_info
    )


@router.post("/auth/logout")
async def logout(current_user: UserInfo = Depends(get_current_user)):
    """Logout user"""
    return {"message": "Successfully logged out"}


@router.get("/auth/me", response_model=UserInfo)
async def get_me(current_user: UserInfo = Depends(get_current_user)):
    """Get current user info"""
    return current_user


# ============= Google Search Console Routes =============

@router.post("/auth/gsc/connect")
async def connect_gsc(
    request: dict, 
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Connect Google Search Console using OAuth authorization code.
    Exchanges the code for access + refresh tokens and stores the refresh token.
    The refresh token allows permanent access without re-authentication.
    """
    from services.gsc_service import GSCService
    from utils.user_manager import update_gsc_token
    import requests as http_requests
    
    gsc_code = request.get('gsc_code')
    if not gsc_code:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="GSC authorization code is required"
        )
    
    # Exchange the authorization code for access + refresh tokens
    try:
        token_response = http_requests.post(
            'https://oauth2.googleapis.com/token',
            data={
                'code': gsc_code,
                'client_id': settings.GOOGLE_CLIENT_ID,
                'client_secret': settings.GOOGLE_CLIENT_SECRET,
                'redirect_uri': 'postmessage',  # Required for popup/ux_mode flows
                'grant_type': 'authorization_code',
            }
        )
        token_data = token_response.json()
        
        if 'error' in token_data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Google token exchange failed: {token_data.get('error_description', token_data['error'])}"
            )
        
        refresh_token = token_data.get('refresh_token')
        access_token = token_data.get('access_token')
        
        if not refresh_token and not access_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No tokens received from Google. Ensure the app is configured for offline access."
            )
        
        # Prefer refresh token (permanent); fall back to access token (short-lived)
        token_to_store = refresh_token if refresh_token else access_token
        is_refresh = bool(refresh_token)
        
        # Verify the token works by trying to fetch properties
        service = GSCService(access_token=access_token, refresh_token=refresh_token)
        properties = await service.get_properties()
        
        # Store the token in database
        update_gsc_token(db, current_user.email, token_to_store, is_refresh_token=is_refresh)
        
        return {
            "message": "Successfully connected to Google Search Console",
            "properties_count": len(properties),
            "connected": True,
            "token_type": "refresh" if is_refresh else "access"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to connect to Google Search Console: {str(e)}"
        )


@router.get("/auth/gsc/properties")
async def get_gsc_properties(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get list of Search Console properties accessible by the user
    Uses the stored GSC token from database
    """
    from services.gsc_service import get_user_properties
    from utils.user_manager import get_user_gsc_token
    
    # Get token from database (returns tuple: token, is_refresh_token)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected. Please connect your Google Search Console account first."
        )
    
    try:
        properties = await get_user_properties(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        return {"properties": properties}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch properties: {str(e)}"
        )


@router.post("/auth/gsc/disconnect")
async def disconnect_gsc(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Disconnect Google Search Console"""
    from utils.user_manager import clear_gsc_token
    from services.gsc_service import invalidate_cache

    try:
        clear_gsc_token(db, current_user.email)
        invalidate_cache(user_email=current_user.email)  # ← clear stale cached properties
        return {"message": "Successfully disconnected from Google Search Console"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to disconnect: {str(e)}"
        )



# ============= Analytics Routes =============

@router.get("/auth/gsc/analytics/{property_url:path}")
async def get_gsc_analytics(
    property_url: str,
    days: int = 365,
    group_by: str = 'daily',
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get complete search analytics including time-series and page data"""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote
    
    property_url = unquote(property_url)
    
    # Get token from database (returns tuple: token, is_refresh_token)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected. Please connect your Google Search Console account first."
        )
        
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        # Fetch chart data and totals
        analytics_data = await service.get_search_analytics(
            property_url, days, group_by, filters_json
        )
        # Fetch pages using the same days window as analytics
        pages = await service.get_pages_with_queries(
            property_url, days, filters_json
        )
        
        return {
            "property_url": property_url,
            "analytics": analytics_data,
            "pages": pages
        }
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch analytics: {error_msg}"
        )

# ============= Cache Management =============

@router.post("/auth/gsc/cache/invalidate")
async def invalidate_gsc_cache(
    current_user: UserInfo = Depends(get_current_user)
):
    """Invalidate the GSC data cache for the current user (forces a fresh fetch)."""
    from services.gsc_service import invalidate_cache
    invalidate_cache(user_email=current_user.email)
    return {"message": "Cache cleared. Next request will fetch fresh data."}


@router.get("/auth/gsc/countries/{property_url:path}")
async def get_gsc_countries(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get clicks/impressions/ctr/position breakdown by country for a GSC property."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote

    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected. Please connect your Google Search Console account first."
        )
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        countries = await service.get_countries(
            property_url, days, filters_json
        )
        return {"countries": countries, "total": len(countries)}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch countries: {error_msg}"
        )


@router.get("/auth/gsc/pages/{property_url:path}")
async def get_gsc_pages(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Return top pages with clicks/impressions/ctr/position for a GSC property."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote
    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="GSC not connected.")
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        pages = await service.get_top_pages(
            property_url, days, filters_json
        )
        return {"pages": pages, "total": len(pages)}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch pages: {error_msg}")


@router.get("/auth/gsc/pages-with-queries/{property_url:path}")
async def get_gsc_pages_with_queries(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Return pages with their ranking queries for the PageSelector."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote
    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="GSC not connected.")
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        pages = await service.get_pages_with_queries(
            property_url, days, filters_json
        )
        return {"pages": pages, "total": len(pages)}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch pages with queries: {error_msg}")


@router.get("/auth/gsc/queries/{property_url:path}")
async def get_gsc_queries(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Return top queries with clicks/impressions/ctr/position for a GSC property."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote
    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="GSC not connected.")
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        queries = await service.get_top_queries(
            property_url, days, filters_json
        )
        return {"queries": queries, "total": len(queries)}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch queries: {error_msg}")


@router.get("/auth/gsc/devices/{property_url:path}")
async def get_gsc_devices(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get clicks/impressions/ctr/position breakdown by device for a GSC property."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote

    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected. Please connect your Google Search Console account first."
        )
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        devices = await service.get_devices(
            property_url, days, filters_json
        )
        return {"devices": devices}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch devices: {error_msg}"
        )


@router.get("/auth/gsc/daily-stats/{property_url:path}")
async def get_gsc_daily_stats(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get per-day unique query/page counts and position-bucket impressions for charts."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote

    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected. Please connect your Google Search Console account first."
        )
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        daily_stats = await service.get_daily_stats(
            property_url, days, filters_json
        )
        return {"daily_stats": daily_stats}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch daily stats: {error_msg}"
        )


@router.get("/auth/gsc/new-lost-rankings/{property_url:path}")
async def get_gsc_new_lost_rankings(
    property_url: str,
    days: int = 28,
    filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Compare current vs previous period to return new and lost queries/pages."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    from urllib.parse import unquote

    property_url = unquote(property_url)
    gsc_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not gsc_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="GSC not connected."
        )
    try:
        service = GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=current_user.email)
        data = await service.get_new_lost_rankings(
            property_url, days, filters_json
        )
        return data
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"You do not have permission to access {property_url}.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch new/lost rankings: {error_msg}"
        )


# ============= GSC Insight Tools (Wizard-style) =============
# All computed from existing Search Console data — no new data source needed.

def _gsc_service_for(db, email):
    """Helper: build a GSCService from the user's stored token, or raise 404."""
    from services.gsc_service import GSCService
    from utils.user_manager import get_user_gsc_token
    gsc_token, is_refresh = get_user_gsc_token(db, email)
    if not gsc_token:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="GSC not connected.")
    return GSCService.from_stored_token(gsc_token, is_refresh_token=is_refresh, user_email=email)


@router.get("/auth/gsc/striking-distance/{property_url:path}")
async def gsc_striking_distance(
    property_url: str, days: int = 28, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Keywords at positions 4–20 — the quickest page-1 wins."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_striking_distance(property_url, days, filters_json=filters_json)
        return {"keywords": data, "total": len(data)}
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


@router.get("/auth/gsc/ctr-opportunities/{property_url:path}")
async def gsc_ctr_opportunities(
    property_url: str, days: int = 28, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Full CTR analysis: site CTR curve (1–20) + every query vs benchmark."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_ctr_analysis(property_url, days, filters_json=filters_json)
        return data
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


@router.get("/auth/gsc/content-decay/{property_url:path}")
async def gsc_content_decay(
    property_url: str, days: int = 28, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Pages losing clicks vs the previous period."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_content_decay(property_url, days, filters_json=filters_json)
        return {"pages": data, "total": len(data)}
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


@router.get("/auth/gsc/cannibalization/{property_url:path}")
async def gsc_cannibalization(
    property_url: str, days: int = 28, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Queries where 2+ of your pages compete in search results."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_cannibalization(property_url, days, filters_json=filters_json)
        return {"queries": data, "total": len(data)}
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


@router.get("/auth/gsc/query-insights/{property_url:path}")
async def gsc_query_insights(
    property_url: str, days: int = 28, history_months: int = 6, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Per-query deltas + monthly time-series (powers user-defined Topic Clusters)."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_query_insights(property_url, days, history_months, filters_json=filters_json)
        return data
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


@router.get("/auth/gsc/topic-clusters/{property_url:path}")
async def gsc_topic_clusters(
    property_url: str, days: int = 28, filters_json: str = None,
    current_user: UserInfo = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Group queries into topic clusters with aggregate metrics."""
    from urllib.parse import unquote
    property_url = unquote(property_url)
    try:
        service = _gsc_service_for(db, current_user.email)
        data = await service.get_topic_clusters(property_url, days, filters_json=filters_json)
        return {"clusters": data, "total": len(data)}
    except HTTPException:
        raise
    except Exception as e:
        msg = str(e)
        if "403" in msg or "sufficient permission" in msg:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"No permission for {property_url}.")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed: {msg}")


# ============= Google Analytics (GA4) Routes =============
# GA4 reuses the SAME stored Google refresh token as GSC — the OAuth consent now
# also requests the analytics.readonly scope, so one sign-in covers both. Users who
# connected before this change must reconnect once to grant Analytics access.

@router.get("/auth/ga4/properties")
async def get_ga4_properties(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List the GA4 properties accessible by the user."""
    from services.analytics_service import get_user_ga4_properties
    from utils.user_manager import get_user_gsc_token

    google_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not google_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Google account not connected. Please connect your Google account first."
        )
    try:
        properties = await get_user_ga4_properties(google_token, is_refresh_token=is_refresh, user_email=current_user.email)
        return {"properties": properties}
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg or "insufficient" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No Analytics access. Reconnect your Google account to grant Analytics permission."
            )
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch GA4 properties: {error_msg}")


@router.get("/auth/ga4/overview/{property_id}")
async def get_ga4_overview(
    property_id: str,
    days: int = 28,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get headline GA4 metrics, daily time-series, deltas and traffic-by-channel."""
    from services.analytics_service import AnalyticsService
    from utils.user_manager import get_user_gsc_token

    google_token, is_refresh = get_user_gsc_token(db, current_user.email)
    if not google_token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Google account not connected. Please connect your Google account first."
        )
    try:
        service = AnalyticsService.from_stored_token(google_token, is_refresh_token=is_refresh, user_email=current_user.email)
        overview = await service.get_overview(property_id, days)
        return overview
    except Exception as e:
        error_msg = str(e)
        if "403" in error_msg or "sufficient permission" in error_msg or "insufficient" in error_msg.lower():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No Analytics access for this property. Reconnect Google or check property permissions."
            )
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch GA4 overview: {error_msg}")


@router.post("/auth/ga4/cache/invalidate")
async def invalidate_ga4_cache(current_user: UserInfo = Depends(get_current_user)):
    """Force a fresh fetch of GA4 data for the current user."""
    from services.analytics_service import invalidate_cache
    invalidate_cache(user_email=current_user.email)
    return {"message": "GA4 cache cleared. Next request will fetch fresh data."}


# ============= SE Ranking Routes =============
# SE Ranking uses TBS's single account API key (settings.SERANKING_API_KEY), shared
# across the tool — no per-user OAuth. These power true keyword rank tracking.

@router.get("/api/seranking/status")
async def seranking_status(current_user: UserInfo = Depends(get_current_user)):
    """Quick check that the SE Ranking key is configured and valid (lists 1 project)."""
    from services.seranking_service import SERankingService
    if not settings.SERANKING_API_KEY:
        return {"configured": False, "message": "SERANKING_API_KEY not set."}
    try:
        projects = await SERankingService().get_projects()
        return {"configured": True, "connected": True, "project_count": len(projects)}
    except Exception as e:
        return {"configured": True, "connected": False, "error": str(e)}


@router.get("/api/seranking/projects")
async def seranking_projects(current_user: UserInfo = Depends(get_current_user)):
    """List SE Ranking projects (tracked client sites)."""
    from services.seranking_service import SERankingService
    if not settings.SERANKING_API_KEY:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SE Ranking not configured (SERANKING_API_KEY missing).")
    try:
        projects = await SERankingService().get_projects()
        return {"projects": projects, "total": len(projects)}
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch SE Ranking projects: {str(e)}")


@router.get("/api/seranking/positions/{site_id}")
async def seranking_positions(
    site_id: int,
    days: int = 30,
    current_user: UserInfo = Depends(get_current_user),
):
    """Get keyword positions + summary for one SE Ranking project."""
    from services.seranking_service import SERankingService
    if not settings.SERANKING_API_KEY:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SE Ranking not configured (SERANKING_API_KEY missing).")
    try:
        data = await SERankingService().get_keyword_positions(site_id, days)
        return data
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to fetch SE Ranking positions: {str(e)}")


# ============= AI Monthly Report Routes =============

@router.post("/api/report/generate/{site_id}")
async def generate_report(
    site_id: int,
    days: int = 30,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Generate an AI monthly SEO report for a SE Ranking project, and save it as a Document."""
    from services.report_generator import generate_monthly_report
    if not settings.SERANKING_API_KEY:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SE Ranking not configured.")
    if not settings.ANTHROPIC_API_KEY:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Anthropic (Claude) API key not configured — needed to write reports.")
    try:
        result = await generate_monthly_report(site_id, days)

        # Persist as a Document so it shows up in the existing Documents UI
        doc_id = str(uuid.uuid4())
        new_doc = Document(
            id=doc_id,
            user_email=current_user.email,
            title=f"Monthly SEO Report — {result['domain']}",
            content_type="SEO Report",
            content={
                "article_markdown": result["report_markdown"],
                "report_context": result["context"],
            },
        )
        db.add(new_doc)
        db.commit()
        db.refresh(new_doc)

        return {"status": "success", "document_id": doc_id, **result}
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Failed to generate report: {str(e)}")


# ============= Analysis Routes =============

@router.get("/api/progress/{analysis_id}")
async def stream_progress(
    analysis_id: str,
    request: Request,
    token: str,
    db: Session = Depends(get_db)
):
    """Stream real-time progress updates using Server-Sent Events (SSE)"""
    # Verify token (EventSource doesn't support custom headers)
    from auth.auth import verify_token
    try:
        payload = verify_token(token)
        user_email = payload.get("sub")
        if not user_email:
            raise HTTPException(status_code=401, detail="Invalid token")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    
    async def event_generator():
        """Generate SSE events with progress updates"""
        try:
            # Send initial connection message
            yield f"data: {json.dumps({'status': 'connected', 'message': 'Progress stream connected'})}\n\n"
            
            last_update = None
            while True:
                # Check if client disconnected
                if await request.is_disconnected():
                    print(f"[{analysis_id}] Client disconnected from progress stream")
                    break
                
                # Get current progress
                progress = await progress_tracker.get(analysis_id)
                
                if progress:
                    # Only send update if progress changed
                    if progress != last_update:
                        yield f"data: {json.dumps(progress)}\n\n"
                        last_update = progress.copy()
                    
                    # If complete or failed, send final message and close
                    if progress['status'] in ['complete', 'failed']:
                        await asyncio.sleep(0.5)  # Give client time to process
                        break
                else:
                    # No progress data yet, send waiting message
                    yield f"data: {json.dumps({'status': 'waiting', 'message': 'Waiting for analysis to start...'})}\n\n"
                
                # Wait before next check (adjust polling interval as needed)
                await asyncio.sleep(0.5)
                
        except asyncio.CancelledError:
            print(f"[{analysis_id}] Progress stream cancelled")
        except Exception as e:
            print(f"[{analysis_id}] Error in progress stream: {str(e)}")
            yield f"data: {json.dumps({'status': 'error', 'message': str(e)})}\n\n"
        finally:
            # Cleanup progress data after stream ends
            await asyncio.sleep(5)  # Keep data for a bit in case of reconnection
            await progress_tracker.cleanup(analysis_id)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"  # Disable nginx buffering
        }
    )


async def process_analysis(analysis_id: str, urls: List[str]):
    """Background task to process analysis with AI"""
    from database import SessionLocal
    db = SessionLocal()
    
    try:
        # Initialize progress tracking (5 main steps)
        await progress_tracker.create(analysis_id, total_steps=5)
        
        print(f"[{analysis_id}] Starting analysis for {len(urls)} URLs...")
        await progress_tracker.update(analysis_id, 1, 'scraping', f'Scraping {len(urls)} website(s)...')
        
        async def check_cancelled():
            if await progress_tracker.is_cancelled(analysis_id):
                print(f"[{analysis_id}] 🛑 Analysis cancelled by user. Stopping.")
                raise asyncio.CancelledError()

        # Scrape URLs
        print(f"[{analysis_id}] Scraping URLs...")
        scraped_data = await scraper.scrape_multiple(urls)
        await check_cancelled()
        
        # Generate knowledge graph with AI
        await progress_tracker.update(analysis_id, 2, 'knowledge_graph', 'Generating knowledge graph with AI...')
        print(f"[{analysis_id}] Generating knowledge graph with AI...")
        knowledge_graph = await kg_generator.generate_graph(scraped_data)
        await check_cancelled()
        
        # Generate topical maps with AI
        await progress_tracker.update(analysis_id, 3, 'topical_map', 'Creating topical maps and content strategy...')
        print(f"[{analysis_id}] Generating topical maps with AI...")
        topical_maps = await topical_generator.generate_multiple(scraped_data)
        await check_cancelled()
        
        # Generate comparison with AI (if multiple URLs)
        comparison = None
        if len(urls) >= 2:
            await progress_tracker.update(analysis_id, 4, 'comparison', 'Comparing websites...')
            print(f"[{analysis_id}] Generating comparison with AI...")
            comparison = await comparator.compare_websites(scraped_data, topical_maps)
            await check_cancelled()
        else:
            # Skip comparison step if single URL
            await progress_tracker.update(analysis_id, 4, 'comparison', 'Skipping comparison (single URL)...')
        
        # Update storage - convert Pydantic models to dicts
        await progress_tracker.update(analysis_id, 5, 'finalizing', 'Saving results...')
        print(f"[{analysis_id}] Analysis complete! Storing results...")
        
        # Convert Pydantic models to dictionaries for JSON serialization
        def serialize_data(data):
            """Convert Pydantic models to dictionaries"""
            if hasattr(data, 'model_dump'):
                return data.model_dump()
            elif isinstance(data, list):
                return [serialize_data(item) for item in data]
            elif isinstance(data, dict):
                return {k: serialize_data(v) for k, v in data.items()}
            return data
        
        database_store.update_analysis(db, analysis_id, {
            'scraped_data': serialize_data(scraped_data),
            'knowledge_graph': serialize_data(knowledge_graph),
            'topical_maps': serialize_data(topical_maps),
            'comparison': serialize_data(comparison) if comparison else None,
        })
        
        # Mark as complete
        await progress_tracker.complete(analysis_id, 'Analysis complete! Redirecting to results...')
        print(f"[{analysis_id}] ✅ Successfully completed!")
        
    except asyncio.CancelledError:
        # User intentionally cancelled/deleted the analysis
        print(f"[{analysis_id}] 🛑 Task terminated: Cleanup complete.")
        return
    except Exception as e:
        print(f"[{analysis_id}] ❌ Error processing analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Update progress tracker with error
        await progress_tracker.fail(analysis_id, str(e))
        
        try:
            db.rollback()  # Rollback failed transaction
            database_store.update_analysis(db, analysis_id, {
                'status': 'failed',
                'error': str(e)
            })
        except Exception as db_error:
            print(f"[{analysis_id}] Failed to update error status: {str(db_error)}")
    finally:
        db.close()


@router.post("/api/analyze", response_model=AnalysisResponse)
async def analyze_urls(
    request: URLAnalysisRequest,
    background_tasks: BackgroundTasks,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Submit URLs for analysis"""
    # Create analysis entry
    analysis_id = database_store.create_analysis(db, current_user.email, request.urls)
    
    # Process in background
    background_tasks.add_task(process_analysis, analysis_id, request.urls)
    
    return AnalysisResponse(
        analysis_id=analysis_id,
        status="processing",
        message=f"Analysis started for {len(request.urls)} URL(s)"
    )


@router.get("/api/results/{analysis_id}")
async def get_results(
    analysis_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get complete analysis results"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    if analysis['status'] == 'processing':
        return {
            "analysis_id": analysis_id,
            "status": "processing",
            "message": "Analysis in progress"
        }
    
    return {
        "analysis_id": analysis['analysis_id'],
        "urls": analysis['urls'],
        "created_at": analysis['created_at'],
        "status": analysis['status']
    }


@router.get("/api/knowledge-graph/{analysis_id}", response_model=dict)
async def get_knowledge_graph(
    analysis_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get knowledge graph for analysis"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Return processing status if not ready
    if analysis['status'] == 'processing':
        return {
            "status": "processing",
            "message": "Knowledge graph is being generated..."
        }
    
    if analysis['status'] == 'failed':
        return {
            "status": "failed",
            "error": analysis.get('error', 'Unknown error')
        }
    
    if not analysis.get('knowledge_graph'):
        return {
            "status": "processing",
            "message": "Knowledge graph not yet available"
        }
    
    return {"knowledge_graph": analysis['knowledge_graph']}


@router.get("/api/topical-map/{analysis_id}", response_model=dict)
async def get_topical_map(
    analysis_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get topical maps for analysis"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Return processing status if not ready
    if analysis['status'] == 'processing':
        return {
            "status": "processing",
            "message": "Topical maps are being generated..."
        }
    
    if analysis['status'] == 'failed':
        return {
            "status": "failed",
            "error": analysis.get('error', 'Unknown error')
        }
    
    if not analysis.get('topical_maps'):
        return {
            "status": "processing",
            "message": "Topical maps not yet available"
        }
    
    return {"topical_maps": analysis['topical_maps']}


@router.get("/api/compare/{analysis_id}", response_model=dict)
async def get_comparison(
    analysis_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get comparison data for analysis"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Return processing status if not ready
    if analysis['status'] == 'processing':
        return {
            "status": "processing",
            "message": "Comparison is being generated..."
        }
    
    if analysis['status'] == 'failed':
        return {
            "status": "failed",
            "error": analysis.get('error', 'Unknown error')
        }
    
    comparison = analysis.get('comparison')
    if not comparison:
        # Check if this was a single URL analysis
        if len(analysis.get('urls', [])) < 2:
            return {
                "status": "not_applicable",
                "message": "Comparison requires 2 or more URLs"
            }
        return {
            "status": "processing",
            "message": "Comparison not yet available"
        }
    
    return {"comparison": comparison}


@router.get("/api/history")
async def get_history(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's analysis history"""
    analyses = database_store.get_user_analyses(db, current_user.email)
    
    # Bangkok timezone
    bangkok_tz = pytz.timezone('Asia/Bangkok')
    
    # Convert UTC timestamps to Bangkok time
    def convert_to_bangkok(utc_dt):
        if utc_dt.tzinfo is None:
            # If naive datetime, assume it's UTC
            utc_dt = pytz.utc.localize(utc_dt)
        # Convert to Bangkok time
        bangkok_dt = utc_dt.astimezone(bangkok_tz)
        # Return ISO format string
        return bangkok_dt.isoformat()
    
    # Return summary info only
    return {
        "analyses": [
            {
                "analysis_id": a['analysis_id'],
                "urls": a['urls'],
                "label": a.get('label'),
                "created_at": convert_to_bangkok(a['created_at']),
                "status": a['status']
            }
            for a in analyses
        ]
    }


@router.delete("/api/analysis/{analysis_id}")
async def delete_analysis(
    analysis_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete an analysis"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Delete the analysis from DB
    database_store.delete_analysis(db, analysis_id)
    
    # Cancel any running background task
    await progress_tracker.cancel(analysis_id)
    
    return {"message": "Analysis deleted successfully"}


@router.patch("/api/analysis/{analysis_id}/label")
async def rename_analysis(
    analysis_id: str,
    request: dict,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Rename / set a custom label for an analysis"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    label = request.get('label', '')
    database_store.rename_analysis(db, analysis_id, label)
    
    return {"message": "Label updated", "label": label.strip() or None}

@router.post("/api/article/{analysis_id}")
async def create_full_article_direct(
    analysis_id: str,
    request: BriefRequest,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate a content brief, then generate the full article immediately."""
    from services.brief_generator import generate_content_brief, generate_full_article
    import uuid
    
    analysis = database_store.get_analysis(db, analysis_id)
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    if analysis['user_email'] != current_user.email:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
        
    try:
        # 1. Generate the brief to give AI context and structure
        brief = await generate_content_brief(
            topic=request.topic,
            category=request.category,
            article_type=request.article_type
        )
        
        # 2. Automatically generate the full article based on the brief
        article_markdown = await generate_full_article(
            topic=request.topic,
            brief_data=brief,
            system_prompt=getattr(request, 'system_prompt', None),
            language=getattr(request, 'language', 'en'),
            tone=getattr(request, 'tone', 'professional'),
            length=getattr(request, 'length', 'medium'),
            audience=getattr(request, 'audience', ''),
            custom_instructions=getattr(request, 'custom_instructions', ''),
        )
        
        brief["article_markdown"] = article_markdown
        
        # Save to database
        doc_id = str(uuid.uuid4())
        new_doc = Document(
            id=doc_id,
            user_email=current_user.email,
            analysis_id=analysis_id,
            title=request.topic,
            content_type="Full Article",
            content=brief
        )
        db.add(new_doc)
        db.commit()
        db.refresh(new_doc)

        return {"status": "success", "article": article_markdown, "document_id": doc_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate article: {str(e)}")

# Keep the old /api/brief just in case, but we will migrate the UI to /api/article.
@router.post("/api/brief/{analysis_id}")
async def create_content_brief(
    analysis_id: str,
    request: BriefRequest,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate an AI content brief for a specific topic"""
    analysis = database_store.get_analysis(db, analysis_id)
    
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis not found"
        )
    
    if analysis['user_email'] != current_user.email:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    try:
        brief = await generate_content_brief(
            topic=request.topic,
            category=request.category,
            article_type=request.article_type
        )
        
        # Save to database
        doc_id = str(uuid.uuid4())
        new_doc = Document(
            id=doc_id,
            user_email=current_user.email,
            analysis_id=analysis_id,
            title=request.topic,
            content_type="Content Brief",
            content=brief
        )
        db.add(new_doc)
        db.commit()
        db.refresh(new_doc)

        return {"status": "success", "brief": brief, "document_id": doc_id}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate brief: {str(e)}"
        )

# ============= Document Routes =============

@router.post("/api/documents", response_model=DocumentDetailResponse)
async def create_document(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new empty document"""
    import uuid
    doc_id = str(uuid.uuid4())
    new_doc = Document(
        id=doc_id,
        user_email=current_user.email,
        title="Untitled Document",
        content_type="Full Article",
        content={"article_markdown": ""}
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)
    return new_doc

@router.get("/api/documents", response_model=List[DocumentResponse])
async def list_documents(
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all saved documents (content briefs) for the current user"""
    documents = db.query(Document).filter(Document.user_email == current_user.email).order_by(Document.updated_at.desc()).all()
    return documents

@router.get("/api/documents/{document_id}", response_model=DocumentDetailResponse)
async def get_document(
    document_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get a specific document by ID"""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if doc.user_email != current_user.email:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    return doc

@router.put("/api/documents/{document_id}", response_model=DocumentDetailResponse)
async def update_document(
    document_id: str,
    request: Request,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a specific document's content"""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if doc.user_email != current_user.email:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    
    update_data = await request.json()
    
    if "content" in update_data:
        new_content = {**(doc.content or {})}
        new_content.update(update_data.get("content", {})) # type: ignore
        doc.content = new_content
        
    if "folder" in update_data:
        doc.folder = update_data.get("folder")
        
    if "title" in update_data:
        doc.title = update_data.get("title")
        
    if "deadline" in update_data:
        deadline_val = update_data.get("deadline")
        if deadline_val:
            try:
                # Handle ISO format strings from frontend (replace Z with +00:00 for older Python versions)
                iso_str = deadline_val.replace("Z", "+00:00")
                from datetime import datetime
                doc.deadline = datetime.fromisoformat(iso_str)
            except Exception as e:
                print(f"Error parsing deadline: {e}")
                doc.deadline = None
        else:
            doc.deadline = None
    
    db.commit()
    return doc

@router.delete("/api/documents/{document_id}")
async def delete_document(
    document_id: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a specific document"""
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if doc.user_email != current_user.email:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    
    db.delete(doc)
    db.commit()
    return {"status": "success", "message": "Document deleted"}

@router.put("/api/folders/{folder_name}")
async def rename_folder(
    folder_name: str,
    new_name: str = Body(..., embed=True),
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Rename a folder (updates all docs for this user)"""
    db.query(Document).filter(
        Document.folder == folder_name,
        Document.user_email == current_user.email
    ).update({Document.folder: new_name})
    db.commit()
    return {"status": "success", "message": f"Folder renamed to {new_name}"}

@router.delete("/api/folders/{folder_name}")
async def delete_folder(
    folder_name: str,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a folder (unsets folder for matching docs)"""
    db.query(Document).filter(
        Document.folder == folder_name,
        Document.user_email == current_user.email
    ).update({Document.folder: None})
    db.commit()
    return {"status": "success", "message": f"Folder {folder_name} deleted (documents kept)"}
@router.post("/api/documents/{document_id}/generate-article")
async def create_full_article(
    document_id: str,
    request: Request,
    current_user: UserInfo = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate a full article from a saved content brief"""
    from services.brief_generator import generate_full_article
    
    doc = db.query(Document).filter(
        Document.id == document_id,
        Document.user_email == current_user.email
    ).first()
    
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    if not doc.content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Document has no brief content to generate from.")
        
    # Accept an optional JSON body for prompt / language / style overrides
    class _ArticleOptions(BaseModel):
        system_prompt: Optional[str] = None
        language: Optional[str] = "en"
        tone: Optional[str] = "professional"
        length: Optional[str] = "medium"
        audience: Optional[str] = ""
        custom_instructions: Optional[str] = ""

    try:
        body = await request.json()
        opts = _ArticleOptions(**body)
    except Exception:
        opts = _ArticleOptions()

    try:
        article_markdown = await generate_full_article(
            topic=doc.title,
            brief_data=doc.content,
            system_prompt=opts.system_prompt,
            language=opts.language,
            tone=opts.tone,
            length=opts.length,
            audience=opts.audience,
            custom_instructions=opts.custom_instructions,
        )
        
        # Update the document
        doc_data = dict(doc.content) if isinstance(doc.content, dict) else {}
        doc_data["article_markdown"] = article_markdown
        
        doc.content = doc_data
        doc.content_type = "Full Article"
        db.commit()
        
        return {"status": "success", "article": article_markdown}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
